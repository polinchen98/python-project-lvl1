#!/usr/bin/env python

def main():
    print('Welcome to the Brain Games!')
