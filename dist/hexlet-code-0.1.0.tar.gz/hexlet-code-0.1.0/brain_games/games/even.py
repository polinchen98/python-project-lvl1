def is_even(digit):
    if digit % 2 == 0:
        return 'yes'
    return 'no'
